﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

using Xamarin.Forms.PancakeView;
using $safeprojectname$.Themes;

namespace $safeprojectname$.Views
{
    public partial class ProfileSport1Page : ContentPage
    {
        public ProfileSport1Page()
        {
            InitializeComponent();

        }

    }
}
