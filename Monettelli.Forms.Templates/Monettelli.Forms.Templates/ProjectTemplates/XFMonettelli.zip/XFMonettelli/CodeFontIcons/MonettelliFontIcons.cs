﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.CodeFontIcons
{
	static class MonettelliFontIcons
	{
		public const string icon_brand_monettelliuikit = "\ue800";
		public const string icon_fly_menu = "\ue801";
		public const string icon_fly_rocket_outline = "\ue802";
		public const string icon_fly_view_dashboard_outline = "\ue803";
		public const string icon_fly_xamarin_outline = "\ue804";
		public const string icon_fly_ballot_outline = "\ue805";
		public const string icon_fly_animation_outline = "\ue806";
		public const string icon_fly_palette_outline = "\ue807";
		public const string icon_fly_file_document_outline = "\ue808";
	}
}
