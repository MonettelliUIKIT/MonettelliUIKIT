﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace $rootnamespace$.Views.Profiles
{
    public partial class Styles
    {
        public Styles()
        {
            InitializeComponent();
        }
    }
}
