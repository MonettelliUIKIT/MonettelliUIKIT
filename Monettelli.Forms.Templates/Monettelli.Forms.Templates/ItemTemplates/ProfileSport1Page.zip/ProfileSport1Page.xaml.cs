﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

using Xamarin.Forms.PancakeView;
using $rootnamespace$.Themes;

namespace $rootnamespace$.Views
{
    public partial class $fileinputname$ProfilePage : ContentPage
    {
        public $fileinputname$ProfilePage()
        {
            InitializeComponent();

        }

    }
}
